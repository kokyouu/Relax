# Task 1 FULL acceptance evidence

Acceptance date: 2026-11-06 Asia/Shanghai.
Tested base: `c9aff0effa5c50e8737539c70e1d7d406c4d9576`.

The exact authoritative base and source digest are in `manifest.json` and
`test-results.json`. This attachment contains selected successful CPU/GPU run
logs, exit codes, JUnit, per-version results, manifests, metrics and environment
versions. `provenance.json` records original and public-copy SHA256 digests.
All 181 original inventory entries were checked before building this attachment.

Only private workspace paths, private network addresses and JUnit hostnames are
redacted. Redacted strings are marked `<WORKSPACE>`, `<PRIVATE_IP>` or
`redacted-host`. Numerical test results and source identities are unchanged.
The original complete evidence remains archived with the delivery package.
Environment installation history, job-launch metadata, generated model weights,
full tokenizer vocabularies and server configuration are not included here.

This is acceptance of a small-fixture FULL integration unit, not full-repository
pytest, production-size model, multi-node or final contest acceptance.
`main-compatibility.json` records the clean application and byte equivalence
of the exact base used for this new CPU/GPU acceptance.

See `REPRODUCE.md` for selected-suite commands and separate GPU/loader steps.
The documentation assembles the tested entry points. The recorded logs are
from the revised source; activate a compatible environment before reproducing.
