# Reproduction entry points

Use a compatible Linux/CUDA project environment; `evidence/environment.json`
and `evidence/runtime-freeze.txt` record the versions used. Two available GPUs
are needed for the TP2 exporter tests. Select only GPUs you are authorized to
use; the commands below do not select physical GPU IDs. Run from the patched
repository root. Choose a fresh output root inside your authorized workspace.

```bash
export RELAX_WORKSPACE="$PWD/outputs/task1-acceptance-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$RELAX_WORKSPACE"
export NVTE_FLASH_ATTN=0 NVTE_FUSED_ATTN=0 NVTE_UNFUSED_ATTN=1
export NCCL_IB_DISABLE=1 NCCL_RAS_ENABLE=0
export NCCL_SOCKET_IFNAME=lo GLOO_SOCKET_IFNAME=lo
export OMP_NUM_THREADS=2 TOKENIZERS_PARALLELISM=false
```

## Selected CPU regression suite

The accepted run produced 227 passed, 0 skipped and 11 subtests passed.
This is not the full repository suite.

```bash
python -m pytest -q -rs \
  tests/cpu/distributed/weight_sync \
  tests/cpu/backends/megatron/weight_conversion/test_qwen2.py \
  tests/cpu/backends/megatron/weight_conversion/test_qwen3_vl_vision.py \
  tests/cpu/backends/megatron/weight_update/test_async_gdn_weight_gather.py \
  tests/cpu/backends/megatron/weight_update/test_bridge_converter_config_broadcast.py \
  tests/cpu/backends/megatron/weight_update/test_bridge_ple_async_gather.py \
  tests/cpu/backends/megatron/weight_update/test_broadcast_converted.py \
  tests/cpu/backends/megatron/weight_update/test_lora_weight_sync.py \
  tests/cpu/backends/megatron/weight_update/test_global_parameter_names.py \
  tests/cpu/backends/megatron/weight_update/test_expert_routing.py \
  --junitxml="$RELAX_WORKSPACE/cpu-results.xml"
```

## Exporters

Run each command to completion before starting its independent loader.
The drivers generate small random model weights without downloading pretrained
source weights. Each driver exports versions 0–5 and verifies HF reconstruction.

```bash
torchrun --standalone --nproc-per-node=2 tests/distributed/weight_sync/run_full_export.py --root "$RELAX_WORKSPACE/direct"
torchrun --standalone --nproc-per-node=2 tests/distributed/weight_sync/run_full_export.py --root "$RELAX_WORKSPACE/bridge" --bridge
torchrun --standalone --nproc-per-node=2 tests/distributed/weight_sync/run_full_vl_export.py --root "$RELAX_WORKSPACE/native-vl"
```

## Synthetic tokenizer fixtures

Unzip the attachment and run its `evidence/reproduction/make_acceptance_assets.py`
with `RELAX_WORKSPACE` still set. The unchanged helper writes tokenizers and the
image probe beneath `$RELAX_WORKSPACE/data`. It needs the packages in the recorded
environment. Point Python at the helper's actual extracted location.

## Independent SGLang consumers

Run the following after the respective exporter has exited and the fixture
helper has completed. A loader uses one available GPU; it need not use all GPUs
that were exposed to the exporter. Keep the same authorized GPU allocation.

```bash
python tests/distributed/weight_sync/run_full_checkpoint_loader.py \
  --store "$RELAX_WORKSPACE/direct/store" --stream megatron --version 5 \
  --output "$RELAX_WORKSPACE/direct-loader" \
  --tokenizer-path "$RELAX_WORKSPACE/data/tiny-qwen3-tokenizer" \
  --max-weight-bytes 33554432 --disk-budget 536870912

python tests/distributed/weight_sync/run_full_checkpoint_loader.py \
  --store "$RELAX_WORKSPACE/bridge/store" --stream megatron --version 5 \
  --output "$RELAX_WORKSPACE/bridge-loader" \
  --tokenizer-path "$RELAX_WORKSPACE/data/tiny-qwen3-tokenizer" \
  --max-weight-bytes 33554432 --disk-budget 536870912

cp "$RELAX_WORKSPACE/native-vl/hf-source/config.json" "$RELAX_WORKSPACE/data/tiny-qwen3-vl-tokenizer/config.json"
python tests/distributed/weight_sync/run_full_checkpoint_loader.py \
  --store "$RELAX_WORKSPACE/native-vl/store" --stream megatron-vl --version 5 \
  --output "$RELAX_WORKSPACE/native-vl-loader" \
  --tokenizer-path "$RELAX_WORKSPACE/data/tiny-qwen3-vl-tokenizer" \
  --max-weight-bytes 268435456 --disk-budget 4294967296 \
  --probe "$RELAX_WORKSPACE/data/tiny-qwen3-vl-tokenizer/probe.json"
```

The loader's result must report success and its root must match the exporter's
version-5 receipt. Tiny random fixtures verify export/load correctness; generated
tokens are not a language-quality benchmark. The accompanying logs record these routes on the base and patch specified
in manifest.json; they do not cover later code revisions.
