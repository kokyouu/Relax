"""Create deterministic synthetic tokenizers for randomly initialized test models."""
import base64
import io
import json
import os
from pathlib import Path

from PIL import Image
from tokenizers import Tokenizer, decoders
from tokenizers.models import WordLevel
from tokenizers.pre_tokenizers import WhitespaceSplit
from transformers import (
    PreTrainedTokenizerFast,
    Qwen2VLImageProcessor,
    Qwen3VLProcessor,
    Qwen3VLVideoProcessor,
)

root = Path(os.environ["RELAX_WORKSPACE"]) / "data"
for name, count in [("tiny-qwen3-tokenizer", 1024), ("tiny-qwen3-vl-tokenizer", 151936)]:
    target = root / name
    target.mkdir(parents=True, exist_ok=True)
    vocabulary = {f"t{i}": i for i in range(count)}
    special = {"<unk>": 0}
    if count > 1024:
        special.update({"<|vision_start|>": 151652, "<|vision_end|>": 151653,
                        "<|image_pad|>": 151655, "<|video_pad|>": 151656})
    for token, index in special.items():
        del vocabulary[f"t{index}"]
        vocabulary[token] = index
    backend = Tokenizer(WordLevel(vocabulary, unk_token="<unk>"))
    backend.pre_tokenizer = WhitespaceSplit()
    backend.decoder = decoders.Sequence([
        decoders.WordPiece(prefix="##", cleanup=False),
        decoders.Replace(" <|image_pad|>", "<|image_pad|>"),
        decoders.Replace(" <|vision_end|>", "<|vision_end|>"),
    ])
    tokenizer = PreTrainedTokenizerFast(
        tokenizer_object=backend, unk_token="<unk>", pad_token="<unk>",
        additional_special_tokens=[token for token in special if token != "<unk>"],
    )
    tokenizer.save_pretrained(target)
    if count > 1024:
        processor = Qwen3VLProcessor(
            image_processor=Qwen2VLImageProcessor(
                patch_size=16, temporal_patch_size=2, merge_size=2,
                min_pixels=4096, max_pixels=4096,
            ),
            tokenizer=tokenizer,
            video_processor=Qwen3VLVideoProcessor(patch_size=16, temporal_patch_size=2, merge_size=2),
        )
        processor.save_pretrained(target)
        picture = Image.new("RGB", (64, 64), (20, 80, 160))
        picture.paste((180, 40, 80), (0, 0, 32, 64))
        buffer = io.BytesIO()
        picture.save(buffer, format="PNG")
        prompt = "t1 <|vision_start|><|image_pad|><|vision_end|> t2"
        batch = processor(text=prompt, images=picture, return_tensors="pt")
        # SGLang expands one image placeholder into the four visual tokens.
        # Supply the raw prompt IDs, not the HF processor's expanded sequence.
        input_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
        assert input_ids.count(151655) == 1
        probe = {
            "input_ids": input_ids,
            "image_data": base64.b64encode(buffer.getvalue()).decode("ascii"),
            "sampling_params": {"temperature": 0, "max_new_tokens": 2},
        }
        (target / "probe.json").write_text(json.dumps(probe, indent=2))
        print("VL_GRID", batch["image_grid_thw"].tolist(), "PIXELS", list(batch["pixel_values"].shape))
    (target / "fixture-manifest.json").write_text(json.dumps({
        "kind": "synthetic test tokenizer", "vocab_size": count, "special_token_ids": special,
        "purpose": "Tiny random model export/load correctness, not language-quality evaluation",
    }, indent=2))
    print("ASSET_READY", target)
